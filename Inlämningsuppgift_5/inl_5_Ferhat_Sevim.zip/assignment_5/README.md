# movie-database-node-react-app

About:

This project was my first backend & frontend web application which were used ExpressJS & ReactJS.

The API will be shown by adding this 'api/' to the end of URL.

# Tech stacks
* Node
  * express
* React
  * bootstrap
  * reactstrap

# How to use
To run this application, you will need Node.js v10.16 or higher

* $ cd assignment_5

* $ npm start


